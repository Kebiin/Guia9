package com.segundo.dao;

import com.segundo.modelo.Usuario;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author familiy
 */@EnableJpaRepositories
public interface UsuarioCrud extends CrudRepository<Usuario, String>{
    
}
