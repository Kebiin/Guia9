package com.segundo.servicio;

import java.util.List;
import com.segundo.modelo.Usuario;
/**
 *
 * @author family
 */
public interface IUsuarioServicio {
    public List<Usuario> listarUsuario();
    public void guardar (Usuario user);
    public void eliminar (Usuario user);
    public Usuario buscar (Usuario user);
    
    
}
