package com.segundo.servicio;



import java.util.List;
import com.segundo.dao.UsuarioCrud;
import com.segundo.modelo.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author family
 */
@Service
public abstract class UsuarioServicioImp implements IUsuarioServicio{
    
    
    @Autowired
    UsuarioCrud crudUser;
    
    @Transactional (readOnly = true)
    public List<Usuario> ListarUsuarios(){
        return (List <Usuario>) crudUser.findAll();
    }
    
    @Transactional
    @Override
    public void eliminar(Usuario user){
        crudUser.delete(user);
    }
    
    @Transactional
    @Override
    public void guardar(Usuario user){
        crudUser.save(user);
    }
    
    @Transactional(readOnly = true)
    @Override
    public Usuario buscar(Usuario user){
        return crudUser.findById(user.getCedula()).orElse(null);
    }    
    
    
    
}
